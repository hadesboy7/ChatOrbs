--[[---------------------------------------------------------------------------
    ChatOrbs - a compact dock of chat-channel buttons.

    One orb per chat target the character can actually use right now, coloured
    by the chat type. Clicking an orb opens the chat edit box already switched
    to that channel; a marker under the dock shows where you are typing. The
    emote orb opens a list of emotes so they do not have to be typed out.

    The row is built from game state, so it never offers a party, raid, guild
    or numbered channel the player is not in.
-----------------------------------------------------------------------------]]

local ADDON_NAME = ...

-- ---------------------------------------------------------------------------
-- Layout
-- ---------------------------------------------------------------------------
local ORB_SIZE   = 20           -- orb diameter at rest
local ORB_GROW   = 2            -- extra diameter when hovered
local ORB_STEP   = 26           -- centre-to-centre spacing
local DOCK_INNER = 6            -- padding between the orbs and the dock edge
local DOCK_H     = ORB_SIZE + DOCK_INNER * 2
local HIT_SIZE   = 24           -- clickable area per orb
local GLOW_SIZE  = 30           -- kept under DOCK_H, so a hover glow stays
                                -- inside the dock instead of haloing the
                                -- orbs next to it
-- Every size here is even, so that snapping the dock to half a pixel per unit
-- still lands each edge on a whole physical pixel.
local MARKER_W, MARKER_H = 14, 4
local CORNER     = 12           -- nine-slice corner, in screen pixels
local CAPTION_SIZE = 12
local CAPTION_SIZE_WIDE = 10    -- two characters (Гр, Ги, Оф, channel 10)
local HOVER_TIME = 0.10         -- seconds for the hover transition

local TEX = "Interface\\AddOns\\ChatOrbs\\Textures\\"
-- Paths carry the extension so the client has nothing to guess.
local TEX_ORB, TEX_SHEEN = TEX .. "Orb.blp", TEX .. "OrbSheen.blp"
local TEX_GLOW = TEX .. "Glow.blp"
local TEX_PANEL, TEX_MARKER = TEX .. "Panel.blp", TEX .. "Marker.blp"

-- Nine-slice texture coordinates: 24px corners in a 64px texture.
local SLICE = { 0, 0.375, 0.625, 1 }

local SHEEN_REST, SHEEN_HOVER = 0.20, 0.30
local GLOW_ALPHA = 0.50
local CAPTION_DARKEN = 0.20     -- glyph colour = chat colour * this

local MIN_SCALE, MAX_SCALE = 0.5, 3.0

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
local _G = _G
local select, type, pairs, ipairs, pcall = select, type, pairs, ipairs, pcall
local tonumber, tostring = tonumber, tostring
local floor, max, min = math.floor, math.max, math.min
local strbyte, strchar, strsub = string.byte, string.char, string.sub
local strlower, strupper = string.lower, string.upper
local tinsert = table.insert
local unpack = _G.unpack or table.unpack
local strtrim = _G.strtrim or function(s)
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local isRU = (_G.GetLocale and GetLocale() == "ruRU") or false

local function T(ru, en)
    if isRU then return ru end
    return en
end

local function Print(msg)
    local frame = _G.DEFAULT_CHAT_FRAME
    if frame then frame:AddMessage("|cffffd100ChatOrbs|r " .. msg) end
end

--- Byte length of the UTF-8 character starting at `i`.
local function CharLen(s, i)
    local b = strbyte(s, i)
    if not b then return 0 end
    if b >= 0xF0 then return 4 end
    if b >= 0xE0 then return 3 end
    if b >= 0xC0 then return 2 end
    return 1
end

--- Uppercases one character. Lua's strupper does not know Cyrillic, so the
--- two-byte Russian range is mapped by hand.
local function UpperChar(c)
    if #c == 1 then return strupper(c) end
    if #c == 2 then
        local b1, b2 = strbyte(c, 1, 2)
        if b1 == 0xD0 and b2 >= 0xB0 and b2 <= 0xBF then         -- а..п
            return strchar(b1, b2 - 0x20)
        elseif b1 == 0xD1 and b2 >= 0x80 and b2 <= 0x8F then     -- р..я
            return strchar(0xD0, b2 + 0x20)
        elseif b1 == 0xD1 and b2 == 0x91 then                    -- ё
            return strchar(0xD0, 0x81)
        end
    end
    return c
end

--- Lowercases one character, Cyrillic included, for case-blind searching.
local function LowerChar(c)
    if #c == 1 then return strlower(c) end
    if #c == 2 then
        local b1, b2 = strbyte(c, 1, 2)
        if b1 == 0xD0 and b2 >= 0x90 and b2 <= 0x9F then         -- А..П
            return strchar(b1, b2 + 0x20)
        elseif b1 == 0xD0 and b2 >= 0xA0 and b2 <= 0xAF then     -- Р..Я
            return strchar(0xD1, b2 - 0x20)
        elseif b1 == 0xD0 and b2 == 0x81 then                    -- Ё
            return strchar(0xD1, 0x91)
        end
    end
    return c
end

local function LowerText(s)
    if type(s) ~= "string" then return "" end
    local out, i = {}, 1
    while i <= #s do
        local n = CharLen(s, i)
        out[#out + 1] = LowerChar(strsub(s, i, i + n - 1))
        i = i + n
    end
    return table.concat(out)
end

--- Number of characters, not bytes: a two-letter Cyrillic caption is four
--- bytes long, and the caption font size is picked by character count.
local function TextLength(s)
    if type(s) ~= "string" then return 0 end
    local count, i = 0, 1
    while i <= #s do
        i = i + CharLen(s, i)
        count = count + 1
    end
    return count
end

local function FirstChar(s)
    if type(s) ~= "string" or s == "" then return "?" end
    return UpperChar(strsub(s, 1, CharLen(s, 1)))
end

local function SetSolid(texture, r, g, b, a)
    if texture.SetColorTexture then
        texture:SetColorTexture(r, g, b, a)
    else
        texture:SetTexture(r, g, b, a)
    end
end

--- Applies a font, dropping back to a font object only when the client
--- really refused it. SetFont answers with a boolean on some clients and with
--- nothing on others, so a nil answer must not be read as failure: doing that
--- threw away every requested size and silently used the fallback instead.
local function ApplyFont(region, path, size, flags, fallbackObject)
    local ok, applied = pcall(region.SetFont, region, path, size, flags)
    if ok and applied ~= false then return true end
    region:SetFontObject(fallbackObject)
    return false
end

local function UpperFirst(s)
    if type(s) ~= "string" or s == "" then return s end
    local n = CharLen(s, 1)
    return UpperChar(strsub(s, 1, n)) .. strsub(s, n + 1)
end

--- First non-empty string among the named globals, else the given default.
local function Global(default, ...)
    for i = 1, select("#", ...) do
        local v = _G[select(i, ...)]
        if type(v) == "string" and v ~= "" then return v end
    end
    return default
end

local function Pack(...)
    local t = { n = select("#", ...) }
    for i = 1, t.n do t[i] = select(i, ...) end
    return t
end

--- Resolves a FrameXML chat helper by its classic global name first and by its
--- ChatFrameUtil name second (the 12.x chat rewrite moved several of them).
local function ChatFunc(globalName, utilName)
    local fn = _G[globalName]
    if type(fn) == "function" then return fn end
    local util = _G.ChatFrameUtil
    if utilName and type(util) == "table" and type(util[utilName]) == "function" then
        return util[utilName]
    end
    return nil
end

-- ---------------------------------------------------------------------------
-- Colours
-- ---------------------------------------------------------------------------
local FALLBACK_COLOR = {
    SAY           = { 1.00, 1.00, 1.00 },
    YELL          = { 1.00, 0.25, 0.25 },
    EMOTE         = { 1.00, 0.50, 0.25 },
    WHISPER       = { 1.00, 0.50, 1.00 },
    BN_WHISPER    = { 0.00, 1.00, 0.96 },
    PARTY         = { 0.67, 0.67, 1.00 },
    RAID          = { 1.00, 0.50, 0.00 },
    INSTANCE_CHAT = { 1.00, 0.50, 0.00 },
    GUILD         = { 0.25, 1.00, 0.25 },
    OFFICER       = { 0.25, 0.75, 0.25 },
    CHANNEL       = { 1.00, 0.75, 0.75 },
}

local function ColorFor(key)
    local info = _G.ChatTypeInfo and _G.ChatTypeInfo[key]
    if type(info) == "table" and type(info.r) == "number" then
        return info.r, info.g, info.b
    end
    local c = FALLBACK_COLOR[key] or FALLBACK_COLOR[(key or ""):gsub("%d+$", "")]
    c = c or FALLBACK_COLOR.SAY
    return c[1], c[2], c[3]
end

-- ---------------------------------------------------------------------------
-- Availability probes
-- ---------------------------------------------------------------------------
local function InGroup()
    if _G.IsInGroup then return IsInGroup() and true or false end
    if _G.GetNumPartyMembers then return GetNumPartyMembers() > 0 end
    if _G.GetNumSubgroupMembers then return GetNumSubgroupMembers() > 0 end
    return false
end

local function InRaid()
    if _G.IsInRaid then return IsInRaid() and true or false end
    if _G.GetNumRaidMembers then return GetNumRaidMembers() > 0 end
    return false
end

local function InGuild()
    return (_G.IsInGuild and IsInGuild()) and true or false
end

local function InInstanceGroup()
    if _G.IsInGroup and _G.LE_PARTY_CATEGORY_INSTANCE then
        local ok, res = pcall(IsInGroup, LE_PARTY_CATEGORY_INSTANCE)
        if ok then return res and true or false end
    end
    return false
end

local function HasBattlenet()
    if _G.SLASH_BNWHISPER1 or _G.BNSendWhisper then return true end
    local api = _G.C_BattleNet
    return (type(api) == "table" and api.GetFriendAccountInfo) and true or false
end

-- ---------------------------------------------------------------------------
-- Fixed chat targets. `label` names the globals the caption letter comes from
-- (ruRU: Сказать -> С, Крик -> К, Шепот -> Ш, Эмоция -> Э).
--
-- THIS LIST IS THE ORDER OF THE ROW. Say first, then Party, then Yell, then
-- the rest; numbered channels are appended after it by AddChannelEntries.
-- Nothing else in the addon sorts the orbs, so moving a line here moves the
-- orb, and the tooltips and the active-channel marker follow along.
-- ---------------------------------------------------------------------------
local STATIC_ENTRIES = {
    { chatType = "SAY",           slash = { "SLASH_SAY1" },
      label = { "SAY" },                                      fallback = "Say" },
    { chatType = "PARTY",         slash = { "SLASH_PARTY1" },
      label = { "PARTY" },          available = InGroup,      fallback = "Party" },
    { chatType = "YELL",          slash = { "SLASH_YELL1" },
      label = { "YELL" },                                     fallback = "Yell" },
    { chatType = "EMOTE",         slash = { "SLASH_EMOTE1" },
      label = { "EMOTE", "CHAT_MSG_EMOTE" }, isEmote = true,  fallback = "Emote" },
    { chatType = "WHISPER",       slash = { "SLASH_WHISPER1", "SLASH_SMART_WHISPER1" },
      label = { "WHISPER" },        needsTarget = true,       fallback = "Whisper" },
    { chatType = "BN_WHISPER",    slash = { "SLASH_BNWHISPER1", "SLASH_WHISPER1" },
      label = { "BN_WHISPER", "BATTLENET_WHISPER", "WHISPER" },
      needsTarget = true,           available = HasBattlenet, fallback = "Whisper" },
    { chatType = "RAID",          slash = { "SLASH_RAID1" },
      label = { "RAID" },           available = InRaid,       fallback = "Raid" },
    { chatType = "INSTANCE_CHAT", slash = { "SLASH_INSTANCE_CHAT1" },
      label = { "INSTANCE_CHAT" },  available = InInstanceGroup,
      fallback = "Instance" },
    { chatType = "GUILD",         slash = { "SLASH_GUILD1" },
      label = { "GUILD" },          available = InGuild,      fallback = "Guild" },
    { chatType = "OFFICER",       slash = { "SLASH_OFFICER1" },
      label = { "OFFICER" },        available = InGuild,      fallback = "Officer" },
}

-- On the ruRU client some of these globals do not start with the letter
-- players know the channel by: SAY comes out as Р, and the Battle.net whisper
-- as О. The chat edit box itself says "Сказать", so for Russian the captions
-- follow the edit box rather than the global. Every other locale derives them
-- as before.
--
-- First letters alone are not enough: Группа and Гильдия are both Г, Шепот
-- and Шепот Battle.net are both Ш, and Офицерский used to collide with the
-- Общий channel. Those four get two characters each (drawn one point
-- smaller), the Battle.net whisper gets Б, and numbered channels are captioned
-- with their number - which is what you type anyway. No two orbs can read
-- the same now.
local RU_LABELS = {
    SAY           = { "С",  "Сказать" },
    YELL          = { "К",  "Крик" },
    EMOTE         = { "Э",  "Эмоция" },
    WHISPER       = { "Ш",  "Шепот" },
    BN_WHISPER    = { "Б",  "Шепот Battle.net" },
    PARTY         = { "Гр", "Группа" },
    RAID          = { "Р",  "Рейд" },
    INSTANCE_CHAT = { "П",  "Подземелье" },
    GUILD         = { "Ги", "Гильдия" },
    OFFICER       = { "Оф", "Офицерский" },
}

-- ---------------------------------------------------------------------------
-- Sticky channel
--
-- Where the edit box reopens is decided by two things. `stickyType`, an
-- attribute on the box, is what the client's own Enter handler puts back into
-- `chatType` once the line has been sent. `ChatTypeInfo[type].sticky` is the
-- same idea for the slash commands the player types by hand, and it is the
-- checkbox in the game's chat settings. Clicking an orb used to set `chatType`
-- only, so the next Enter went back to whatever the client had sticky - Say,
-- as a rule. With the option on, an orb click sets both, and the box reopens
-- in the channel last written to.
--
-- Yell and Emote are left out on purpose: making them sticky is how a whole
-- conversation ends up yelled across the zone.
-- ---------------------------------------------------------------------------
local STICKY_TYPES = {
    SAY = true, PARTY = true, RAID = true, INSTANCE_CHAT = true,
    GUILD = true, OFFICER = true, WHISPER = true, BN_WHISPER = true,
    CHANNEL = true,
}

local savedSticky   -- the client's own flags, kept so the option can be undone

--- Mirrors the option onto ChatTypeInfo, so a hand-typed /g sticks as well.
local function ApplyStickyFlags()
    local info = _G.ChatTypeInfo
    if type(info) ~= "table" then
        -- Not an error worth a message: without ChatTypeInfo there are no
        -- flags to set, and the stickyType attribute the orbs rely on is set
        -- separately in OpenChatFor.
        return
    end
    if ChatOrbsDB and ChatOrbsDB.sticky then
        if not savedSticky then
            savedSticky = {}
            for key in pairs(STICKY_TYPES) do
                local entry = info[key]
                if type(entry) == "table" then
                    -- `false` stands for "was not set at all", so turning the
                    -- option off restores that rather than writing a 0. It is
                    -- spelled out because `cond and false or x` can never
                    -- yield false in Lua.
                    if entry.sticky == nil then
                        savedSticky[key] = false
                    else
                        savedSticky[key] = entry.sticky
                    end
                end
            end
        end
        for key in pairs(STICKY_TYPES) do
            local entry = info[key]
            if type(entry) == "table" then entry.sticky = 1 end
        end
    elseif savedSticky then
        for key, value in pairs(savedSticky) do
            local entry = info[key]
            if type(entry) == "table" then
                if value == false then
                    entry.sticky = nil
                else
                    entry.sticky = value
                end
            end
        end
        savedSticky = nil
    end
end

--- Remembers the channel an orb just opened, so Enter comes back to it.
local function RememberSticky(editBox, chatType)
    if not (ChatOrbsDB and ChatOrbsDB.sticky) then return end
    if not STICKY_TYPES[chatType] then return end
    if not editBox.SetAttribute then return end
    editBox:SetAttribute("stickyType", chatType)
end

-- ---------------------------------------------------------------------------
-- Chat edit box
-- ---------------------------------------------------------------------------
local function GetEditBox()
    local choose = ChatFunc("ChatEdit_ChooseBoxForSend", "ChooseBoxForSend")
    if choose then
        local ok, box = pcall(choose, _G.DEFAULT_CHAT_FRAME)
        if ok and box then return box end
    end
    local df = _G.DEFAULT_CHAT_FRAME
    return (df and df.editBox) or _G.ChatFrame1EditBox
end

local function WhisperTarget()
    if _G.UnitExists and UnitExists("target") and UnitIsPlayer("target")
        and (not _G.UnitCanAttack or not UnitCanAttack("player", "target")) then
        local name
        if _G.GetUnitName then name = GetUnitName("target", true) end
        if type(name) ~= "string" or name == "" then
            name = _G.UnitName and UnitName("target")
        end
        if type(name) == "string" and name ~= "" then
            return (name:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
        end
    end
    for _, fname in ipairs({ "ChatEdit_GetLastTellTarget", "ChatEdit_GetLastToldTarget" }) do
        local fn = _G[fname]
        if type(fn) == "function" then
            local ok, last = pcall(fn)
            if ok and type(last) == "string" and last ~= "" then return last end
        end
    end
    return nil
end

local ChatOrbs = { buttons = {} }

local function OpenChatFor(entry)
    local editBox = GetEditBox()
    if not editBox then return end

    local activate = ChatFunc("ChatEdit_ActivateChat", "ActivateChat")
    if activate then pcall(activate, editBox) end
    if not editBox:IsShown() then editBox:Show() end
    editBox:SetFocus()

    local updateHeader = ChatFunc("ChatEdit_UpdateHeader", "UpdateHeader")
    local chatType = entry.chatType
    local target
    if entry.needsTarget and chatType == "WHISPER" then
        target = WhisperTarget()
    end

    -- Primary path: the attribute protocol ChatEdit_SendText reads on Enter.
    -- Whatever the player already typed is left alone.
    if updateHeader and not (entry.needsTarget and not target) then
        editBox:SetAttribute("chatType", chatType)
        if chatType == "CHANNEL" then
            editBox:SetAttribute("channelTarget", entry.channelId)
        elseif target then
            editBox:SetAttribute("tellTarget", target)
        end
        RememberSticky(editBox, chatType)
        pcall(updateHeader, editBox)
        ChatOrbs:UpdateMarker()
        return
    end

    -- Fallback: put the slash command in the box. Used for a whisper with no
    -- obvious recipient, and on any client where the chat helpers could not be
    -- resolved. The text stays a valid command either way, so pressing Enter
    -- still reaches the right channel.
    local slash = entry.slashText
    if slash then
        editBox:SetText(slash .. " ")
        local parse = ChatFunc("ChatEdit_ParseText", "ParseText")
        if parse then pcall(parse, editBox, 0) end
        if editBox.SetCursorPosition and editBox.GetNumLetters then
            editBox:SetCursorPosition(editBox:GetNumLetters() or 0)
        end
    else
        editBox:SetAttribute("chatType", chatType)
        if chatType == "CHANNEL" then
            editBox:SetAttribute("channelTarget", entry.channelId)
        end
        RememberSticky(editBox, chatType)
        if updateHeader then pcall(updateHeader, editBox) end
    end
    ChatOrbs:UpdateMarker()
end

-- ---------------------------------------------------------------------------
-- Entry list
-- ---------------------------------------------------------------------------
local function AddChannelEntries(out)
    if type(_G.GetChannelList) ~= "function" then return end
    local ok, list = pcall(function() return Pack(GetChannelList()) end)
    if not ok or type(list) ~= "table" then return end

    -- GetChannelList yields (id, name) pairs on old clients and
    -- (id, name, disabled) triplets on current ones, so scan for every
    -- number-followed-by-string adjacency instead of assuming a stride.
    local seen = {}
    local i = 1
    while i < list.n do
        local id, name = list[i], list[i + 1]
        if type(id) == "number" and type(name) == "string"
            and id == floor(id) and id > 0 and id < 1000
            and name ~= "" and not seen[id] then
            seen[id] = true
            local disabled = list[i + 2]
            if type(disabled) ~= "boolean" then disabled = false end
            if not disabled then
                out[#out + 1] = {
                    key       = "CHANNEL" .. id,
                    chatType  = "CHANNEL",
                    channelId = id,
                    colorKey  = "CHANNEL" .. id,
                    -- The number, not the first letter: it never collides
                    -- with another orb and it is what /1, /2 ... already say.
                    caption   = tostring(id),
                    title     = id .. ". " .. name,
                    slashText = "/" .. id,
                }
            end
            i = i + 2
        else
            i = i + 1
        end
    end
end

local function BuildEntries()
    local entries = {}
    for _, def in ipairs(STATIC_ENTRIES) do
        if (not def.available) or def.available() then
            local title = Global(def.fallback, unpack(def.label))
            local caption = FirstChar(title)
            local override = isRU and RU_LABELS[def.chatType]
            if override then
                caption, title = override[1], override[2]
            end
            local slash
            for _, name in ipairs(def.slash) do
                local value = _G[name]
                if type(value) == "string" and value ~= "" then
                    slash = value
                    break
                end
            end
            entries[#entries + 1] = {
                key         = def.chatType,
                chatType    = def.chatType,
                colorKey    = def.chatType,
                caption     = caption,
                title       = title,
                slashText   = slash,
                needsTarget = def.needsTarget,
                isEmote     = def.isEmote,
            }
        end
    end
    AddChannelEntries(entries)
    return entries
end

-- ---------------------------------------------------------------------------
-- Nine-slice panel
-- ---------------------------------------------------------------------------
local function CreatePanel(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel.pieces = {}
    local cols = { "LEFT", "MID", "RIGHT" }
    local rows = { "TOP", "MID", "BOTTOM" }
    for r = 1, 3 do
        for c = 1, 3 do
            local tex = panel:CreateTexture(nil, "BACKGROUND")
            tex:SetTexCoord(SLICE[c], SLICE[c + 1], SLICE[r], SLICE[r + 1])
            panel.pieces[rows[r] .. cols[c]] = tex
        end
    end
    panel.Layout = function(self)
        local p = self.pieces
        local corner = CORNER
        local function put(tex, point, relPoint, x, y, w, h)
            tex:ClearAllPoints()
            tex:SetPoint(point, self, relPoint, x, y)
            if w then tex:SetWidth(w) end
            if h then tex:SetHeight(h) end
        end
        put(p.TOPLEFT, "TOPLEFT", "TOPLEFT", 0, 0, corner, corner)
        put(p.TOPRIGHT, "TOPRIGHT", "TOPRIGHT", 0, 0, corner, corner)
        put(p.BOTTOMLEFT, "BOTTOMLEFT", "BOTTOMLEFT", 0, 0, corner, corner)
        put(p.BOTTOMRIGHT, "BOTTOMRIGHT", "BOTTOMRIGHT", 0, 0, corner, corner)

        p.TOPMID:ClearAllPoints()
        p.TOPMID:SetPoint("TOPLEFT", p.TOPLEFT, "TOPRIGHT")
        p.TOPMID:SetPoint("BOTTOMRIGHT", p.TOPRIGHT, "BOTTOMLEFT")
        p.BOTTOMMID:ClearAllPoints()
        p.BOTTOMMID:SetPoint("TOPLEFT", p.BOTTOMLEFT, "TOPRIGHT")
        p.BOTTOMMID:SetPoint("BOTTOMRIGHT", p.BOTTOMRIGHT, "BOTTOMLEFT")
        p.MIDLEFT:ClearAllPoints()
        p.MIDLEFT:SetPoint("TOPLEFT", p.TOPLEFT, "BOTTOMLEFT")
        p.MIDLEFT:SetPoint("BOTTOMRIGHT", p.BOTTOMLEFT, "TOPRIGHT")
        p.MIDRIGHT:ClearAllPoints()
        p.MIDRIGHT:SetPoint("TOPLEFT", p.TOPRIGHT, "BOTTOMLEFT")
        p.MIDRIGHT:SetPoint("BOTTOMRIGHT", p.BOTTOMRIGHT, "TOPRIGHT")
        p.MIDMID:ClearAllPoints()
        p.MIDMID:SetPoint("TOPLEFT", p.TOPLEFT, "BOTTOMRIGHT")
        p.MIDMID:SetPoint("BOTTOMRIGHT", p.BOTTOMRIGHT, "TOPLEFT")
    end
    panel.Restyle = function(self, flat)
        for _, tex in pairs(self.pieces) do
            if flat then
                if tex.SetColorTexture then
                    tex:SetColorTexture(0.05, 0.05, 0.06, 0.8)
                else
                    tex:SetTexture(0.05, 0.05, 0.06, 0.8)
                end
                tex:SetTexCoord(0, 1, 0, 1)
            else
                tex:SetTexture(TEX_PANEL)
            end
        end
        if not flat then
            local cols2 = { "LEFT", "MID", "RIGHT" }
            local rows2 = { "TOP", "MID", "BOTTOM" }
            for r = 1, 3 do
                for c = 1, 3 do
                    self.pieces[rows2[r] .. cols2[c]]
                        :SetTexCoord(SLICE[c], SLICE[c + 1], SLICE[r], SLICE[r + 1])
                end
            end
        end
    end
    panel:Layout()
    return panel
end

-- ---------------------------------------------------------------------------
-- Hover transition: one shared OnUpdate that detaches when nothing is moving
-- ---------------------------------------------------------------------------
local tweening, tweenFrame = {}, nil

local function ApplyVisual(button)
    local t = button.hoverAmount or 0
    local size = ORB_SIZE + ORB_GROW * t - (button.pressed and 1.5 or 0)
    local drop = button.pressed and -1 or 0
    button.orb:SetWidth(size); button.orb:SetHeight(size)
    button.sheen:SetWidth(size); button.sheen:SetHeight(size)
    button.orb:SetPoint("CENTER", button, "CENTER", 0, drop)
    button.sheen:SetPoint("CENTER", button, "CENTER", 0, drop)
    button.caption:SetPoint("CENTER", button, "CENTER", 0, drop)
    button.sheen:SetAlpha(SHEEN_REST + (SHEEN_HOVER - SHEEN_REST) * t)
    button.glow:SetAlpha(GLOW_ALPHA * t)
end

local function TweenStep(self, elapsed)
    local step = (elapsed or 0) / HOVER_TIME
    local busy = false
    for button, target in pairs(tweening) do
        local current = button.hoverAmount or 0
        if current < target then
            current = min(target, current + step)
        else
            current = max(target, current - step)
        end
        button.hoverAmount = current
        ApplyVisual(button)
        if current == target then
            tweening[button] = nil
        else
            busy = true
        end
    end
    if not busy then self:SetScript("OnUpdate", nil) end
end

local function SetHover(button, on)
    tweening[button] = on and 1 or 0
    if not tweenFrame then tweenFrame = CreateFrame("Frame") end
    tweenFrame:SetScript("OnUpdate", TweenStep)
end

-- ---------------------------------------------------------------------------
-- Emotes
-- ---------------------------------------------------------------------------
-- The emotes worth having under the cursor. Exactly 24, which is one full
-- screen of the list, so the short view needs no scrolling at all. Сесть
-- comes first because that is the one reached for most, then laughing. The
-- order here is the order on screen, read left to right.
--
-- Everything else the client knows is one keystroke away: typing in the
-- search box searches the lot, and /chatorbs emotes switches the list to
-- the full set for good.
local EMOTE_IMPORTANT = {
    "SIT", "LAUGH", "ROFL",
    "GIGGLE", "SMILE", "CHEER",
    "APPLAUD", "DANCE", "HELLO",
    "WAVE", "BYE", "THANK",
    "BOW", "YES", "NO",
    "SORRY", "CONGRATULATE", "HUG",
    "SHRUG", "CRY", "POINT",
    "SLEEP", "FLEX", "SALUTE",
}

local emoteList

--- Russian names for the emotes.
---
--- The list used to show the client's own slash commands, and those read
--- badly: they are written as one glued word ("/отдатьчесть" -> "Отдатьчесть",
--- "/пожатьплечами" -> "Пожатьплечами") and they mix nouns with verbs, so
--- "Танец" sat next to "Плакать". Every name here is an infinitive, spelled
--- out with spaces, which makes the whole list read the same way. A token that
--- is not listed still shows the client's own wording, so nothing disappears
--- from the list, and the client's wording stays searchable either way.
local EMOTE_RU = {
    AGREE          = "Согласиться",
    AMAZE          = "Изумиться",
    ANGRY          = "Злиться",
    APOLOGIZE      = "Извиниться",
    APPLAUD        = "Аплодировать",
    ATTACKMYTARGET = "Указать цель",
    BASHFUL        = "Смущаться",
    BECKON         = "Поманить",
    BEG            = "Умолять",
    BITE           = "Укусить",
    BLEED          = "Кровоточить",
    BLINK          = "Моргнуть",
    BLUSH          = "Покраснеть",
    BOGGLE         = "Опешить",
    BONK           = "Стукнуть себя",
    BORED          = "Скучать",
    BOUNCE         = "Подпрыгивать",
    BOW            = "Поклониться",
    BRANDISH       = "Потрясти оружием",
    BURP           = "Рыгнуть",
    BYE            = "Попрощаться",
    CACKLE         = "Хохотать",
    CALM           = "Успокоить",
    CHARGE         = "Ринуться в бой",
    CHEER          = "Ликовать",
    CHICKEN        = "Кудахтать",
    CHUCKLE        = "Хмыкнуть",
    COLD           = "Мёрзнуть",
    COMFORT        = "Утешить",
    COMMEND        = "Похвалить",
    CONFUSED       = "Растеряться",
    CONGRATULATE   = "Поздравить",
    COUGH          = "Кашлять",
    COWER          = "Съёжиться",
    CRACK          = "Размять костяшки",
    CRY            = "Плакать",
    CUDDLE         = "Приласкать",
    CURIOUS        = "Любопытствовать",
    CURTSEY        = "Сделать реверанс",
    DANCE          = "Танцевать",
    DRINK          = "Пить",
    DROOL          = "Пускать слюни",
    DUCK           = "Пригнуться",
    EAT            = "Есть",
    EYE            = "Разглядывать",
    FART           = "Испортить воздух",
    FIDGET         = "Переминаться",
    FLEE           = "Убегать",
    FLEX           = "Напрячь мускулы",
    FLIRT          = "Флиртовать",
    FLOP           = "Повалиться",
    FOLLOW         = "Следовать",
    FROWN          = "Нахмуриться",
    GASP           = "Ахнуть",
    GAZE           = "Засмотреться",
    GIGGLE         = "Хихикать",
    GLARE          = "Сверкнуть глазами",
    GLOAT          = "Злорадствовать",
    GOLFCLAP       = "Вежливо похлопать",
    GREET          = "Поприветствовать",
    GRIN           = "Ухмыльнуться",
    GROAN          = "Застонать",
    GROVEL         = "Пасть ниц",
    GROWL          = "Зарычать",
    GUFFAW         = "Расхохотаться",
    HAIL           = "Окликнуть",
    HAPPY          = "Радоваться",
    HEALME         = "Просить лечения",
    HELLO          = "Поздороваться",
    HELPME         = "Просить помощи",
    HICCUP         = "Икать",
    HIGHFIVE       = "Дать пять",
    HUG            = "Обнять",
    HUNGRY         = "Проголодаться",
    IMPATIENT      = "Нетерпеливо ждать",
    INCOMING       = "Предупредить",
    INSULT         = "Оскорбить",
    INTRODUCE      = "Представиться",
    JK             = "Пошутить",
    KISS           = "Поцеловать",
    KNEEL          = "Встать на колени",
    LAUGH          = "Смеяться",
    LAYDOWN        = "Лечь",
    LICK           = "Лизнуть",
    LISTEN         = "Прислушаться",
    LOST           = "Заблудиться",
    LOVE           = "Признаться",
    MASSAGE        = "Размять плечи",
    MOAN           = "Томно стонать",
    MOCK           = "Насмехаться",
    MOO            = "Мычать",
    MOURN          = "Скорбеть",
    NERVOUS        = "Нервничать",
    NO             = "Отказаться",
    NOSEPICK       = "Ковырять в носу",
    OOM            = "Кончилась мана",
    OPENFIRE       = "Открыть огонь",
    PANIC          = "Паниковать",
    PEER           = "Вглядываться",
    PET            = "Погладить",
    PITY           = "Жалеть",
    PLEAD          = "Молить",
    POINT          = "Указать",
    POKE           = "Толкнуть",
    PONDER         = "Задуматься",
    POUNCE         = "Прыгнуть",
    PRAISE         = "Воздать хвалу",
    PRAY           = "Молиться",
    PURR           = "Мурлыкать",
    PUZZLE         = "Недоумевать",
    QUESTION       = "Спросить",
    RAISE          = "Поднять руку",
    READ           = "Читать",
    READY          = "Быть готовым",
    ROAR           = "Взреветь",
    ROFL           = "Валяться от смеха",
    RUDE           = "Нагрубить",
    SALUTE         = "Отдать честь",
    SCARED         = "Испугаться",
    SCRATCH        = "Почесаться",
    SEXY           = "Соблазнять",
    SHIMMY         = "Трястись",
    SHIVER         = "Дрожать",
    SHOO           = "Прогонять",
    SHRUG          = "Пожать плечами",
    SHY            = "Стесняться",
    SIGH           = "Вздохнуть",
    SILLY          = "Дурачиться",
    SIT            = "Сесть",
    SLAP           = "Дать пощёчину",
    SLEEP          = "Спать",
    SMELL          = "Принюхаться",
    SMILE          = "Улыбнуться",
    SMIRK          = "Усмехнуться",
    SNARL          = "Огрызнуться",
    SNICKER        = "Посмеиваться",
    SNIFF          = "Шмыгнуть носом",
    SNUB           = "Пренебречь",
    SOOTHE         = "Приободрить",
    SORRY          = "Просить прощения",
    SPIT           = "Плюнуть",
    STAND          = "Встать",
    STARE          = "Уставиться",
    SURPRISED      = "Удивиться",
    SURRENDER      = "Сдаться",
    TALK           = "Говорить",
    TALKEX         = "Восклицать",
    TAP            = "Постукивать ногой",
    TAUNT          = "Подначивать",
    TEASE          = "Поддразнить",
    THANK          = "Поблагодарить",
    THIRSTY        = "Хотеть пить",
    THREATEN       = "Угрожать",
    TICKLE         = "Пощекотать",
    TIRED          = "Устать",
    TRAIN          = "Изобразить поезд",
    TRUCE          = "Просить мира",
    TWIDDLE        = "Теребить",
    VETO           = "Возразить",
    VICTORY        = "Торжествовать",
    VIOLIN         = "Играть на скрипке",
    WAIT           = "Просить подождать",
    WAVE           = "Помахать",
    WELCOME        = "Радушно встретить",
    WHINE          = "Хныкать",
    WHISTLE        = "Свистеть",
    WICKED         = "Злобно скалиться",
    WINK           = "Подмигнуть",
    WORK           = "Работать",
    YAWN           = "Зевать",
    YES            = "Кивнуть",
}
ChatOrbs.emoteNames = EMOTE_RU

--- The wording the client itself uses for an emote, from its slash commands.
--- It is the search needle, and the label for an emote EMOTE_RU misses.
local function ClientEmoteText(index)
    local best
    for n = 1, 4 do
        local cmd = _G["EMOTE" .. index .. "_CMD" .. n]
        if type(cmd) == "string" and cmd ~= "" then
            local text = (cmd:gsub("^/", ""))
            if text ~= "" then
                if not best then best = text end
                -- The ruRU client lists both "/yes" and a Russian spelling for
                -- some emotes; an English word in the middle of a Russian list
                -- reads like a bug, so prefer the Cyrillic one.
                local lead = strbyte(text, 1)
                if isRU and lead and lead >= 0xC0 then return text end
            end
        end
    end
    return best
end

--- One list entry: the name shown, the command behind it, and everything
--- the entry can be found by.
local function EmoteEntry(index, token)
    local clientText = ClientEmoteText(index)
    local label = isRU and EMOTE_RU[token] or nil
    if not label then label = UpperFirst(clientText or strlower(token)) end
    local search = LowerText(label) .. " " .. strlower(token)
    if clientText then search = search .. " " .. LowerText(clientText) end
    return { token = token, label = label, search = search, command = clientText }
end

--- Every emote the client knows: the favourites first, then the rest in
--- alphabetical order. Hardcoding a short list is what hid /sit, so the list
--- is now read out of the client instead of being written down here.
local function BuildEmoteList()
    if emoteList then return emoteList end

    local byToken, found = {}, {}
    for i = 1, 1000 do
        local token = _G["EMOTE" .. i .. "_TOKEN"]
        if type(token) == "string" and token ~= "" and not byToken[token] then
            local entry = EmoteEntry(i, token)
            -- An emote the client publishes no slash command for is one the
            -- player cannot type either, and DoEmote has nothing to play for
            -- it. Those were the buttons that did nothing when clicked.
            if entry.command then
                byToken[token] = entry
                found[#found + 1] = entry
            end
        end
    end

    emoteList = {}
    local used = {}
    for _, token in ipairs(EMOTE_IMPORTANT) do
        local entry = byToken[token]
        if entry and not used[entry] then
            used[entry] = true
            entry.important = true
            emoteList[#emoteList + 1] = entry
        end
    end

    local rest = {}
    for _, entry in ipairs(found) do
        if not used[entry] then rest[#rest + 1] = entry end
    end
    table.sort(rest, function(a, b) return a.search < b.search end)
    for _, entry in ipairs(rest) do emoteList[#emoteList + 1] = entry end

    -- A client with no emote globals at all still gets a usable list.
    if #emoteList == 0 then
        for _, token in ipairs(EMOTE_IMPORTANT) do
            local label = (isRU and EMOTE_RU[token]) or UpperFirst(strlower(token))
            emoteList[#emoteList + 1] = {
                token = token, label = label, search = LowerText(label),
                important = true,
            }
        end
    end
    return emoteList
end

local EMOTE_COLS, EMOTE_ROWS = 3, 8
local EMOTE_CELL_W, EMOTE_CELL_H, EMOTE_PAD, EMOTE_SEARCH_H = 144, 20, 10, 22
-- A strip under the grid for the scroll hint. Without it the hint was drawn
-- over the bottom row of names.
local EMOTE_HINT_H = 12

local picker, pickerBlocker
local pickerCells, pickerMatches, pickerOffset = {}, {}, 0
local pickerShort = true        -- showing the short list, not a search result

local function HidePicker()
    if picker then picker:Hide() end
end

local function PickerMaxOffset()
    return max(0, math.ceil(#pickerMatches / EMOTE_COLS) - EMOTE_ROWS)
end

local function RefreshPicker()
    if not picker then return end
    local limit = PickerMaxOffset()
    if pickerOffset > limit then pickerOffset = limit end
    if pickerOffset < 0 then pickerOffset = 0 end

    for index, cell in ipairs(pickerCells) do
        local entry = pickerMatches[pickerOffset * EMOTE_COLS + index]
        cell.entry = entry
        if entry then
            cell.text:SetText(entry.label)
            cell.text:SetTextColor(0.88, 0.88, 0.92)
            cell:Show()
        else
            cell:Hide()
        end
    end

    if #pickerMatches == 0 then picker.empty:Show() else picker.empty:Hide() end
    if limit > 0 then
        picker.more:SetText(T("колесо — прокрутка", "scroll for more"))
        picker.more:Show()
    elseif pickerShort then
        picker.more:SetText(T("остальные эмоции — через поиск",
                              "search for the rest"))
        picker.more:Show()
    else
        picker.more:Hide()
    end
end

local function FilterPicker(query)
    local all = BuildEmoteList()
    pickerMatches = {}
    query = LowerText(strtrim(query or ""))
    -- With nothing typed the list shows the short set; typing searches
    -- everything the client knows, so nothing is out of reach.
    pickerShort = query == "" and not (ChatOrbsDB and ChatOrbsDB.allEmotes)
    for _, entry in ipairs(all) do
        local matches
        if pickerShort then
            matches = entry.important
        else
            matches = query == "" or entry.search:find(query, 1, true)
        end
        if matches then pickerMatches[#pickerMatches + 1] = entry end
    end
    pickerOffset = 0
    RefreshPicker()
end

local reportedEmote = {}

--- Runs a slash command the way typing it would.
local function RunSlashCommand(text)
    local editBox = GetEditBox()
    if not editBox or not editBox.SetText then return false end
    local send = ChatFunc("ChatEdit_SendText", "SendText")
    if not send then return false end
    local saved = editBox.GetText and editBox:GetText() or ""
    editBox:SetText(text)
    local ok = pcall(send, editBox, 0)
    editBox:SetText(saved or "")
    return ok and true or false
end

--- Performs an emote, and says so when it cannot.
---
--- DoEmote used to be called inside a bare pcall, so a click on an emote the
--- client would not play did nothing and said nothing. Now the slash command
--- the client publishes for that emote is tried as a second path, and the
--- first failure is reported - once per emote, so a stuck one does not fill
--- the chat frame.
local function PerformEmote(entry)
    if not entry then return end
    HidePicker()

    local failure
    if type(_G.DoEmote) == "function" then
        local ok, err = pcall(DoEmote, entry.token)
        if ok then return end
        failure = tostring(err)
    else
        failure = T("в этом клиенте нет DoEmote", "this client has no DoEmote")
    end

    local command = entry.command and ("/" .. entry.command) or nil
    local recovered = command ~= nil and RunSlashCommand(command)
    if reportedEmote[entry.token] then return end
    reportedEmote[entry.token] = true

    local what = T("эмоция «", "emote '") .. entry.label
                 .. T("» (", "' (") .. entry.token .. "): " .. failure
    if recovered then
        Print(what .. T(". Выполнил командой ", ". Ran ") .. command
              .. T(".", " instead."))
    elseif command then
        Print(what .. T(". Команда ", ". ") .. command
              .. T(" тоже не прошла.", " did not work either."))
    else
        Print(what .. T(". Клиент не даёт для неё команды.",
                        ". The client offers no command for it."))
    end
end

local function CreatePicker()
    if picker then return picker end

    pickerBlocker = CreateFrame("Button", nil, UIParent)
    pickerBlocker:SetAllPoints(UIParent)
    pickerBlocker:SetFrameStrata("DIALOG")
    pickerBlocker:Hide()
    pickerBlocker:SetScript("OnClick", HidePicker)

    picker = CreateFrame("Frame", "ChatOrbsEmotePicker", UIParent)
    picker:SetFrameStrata("DIALOG")
    picker:SetWidth(EMOTE_COLS * EMOTE_CELL_W + EMOTE_PAD * 2)
    picker:SetHeight(EMOTE_PAD * 2 + EMOTE_SEARCH_H + 6
                     + EMOTE_ROWS * EMOTE_CELL_H + EMOTE_HINT_H)
    picker:EnableMouse(true)
    picker:EnableMouseWheel(true)
    -- The list is wider than the dock, so near a screen edge it would
    -- otherwise hang off it.
    picker:SetClampedToScreen(true)
    picker:Hide()

    picker.panel = CreatePanel(picker)
    picker.panel:SetAllPoints(picker)
    -- The panel is the backdrop. Pin it below the cells instead of trusting
    -- the order the frames happened to be created in.
    picker.panel:SetFrameLevel(max(1, picker:GetFrameLevel()))
    picker.panel:Restyle(ChatOrbsDB and ChatOrbsDB.flat)

    local fontPath, fontFlags
    local source = _G.GameFontNormal
    if source and source.GetFont then
        local path, _, flags = source:GetFont()
        fontPath, fontFlags = path, flags
    end
    fontPath = fontPath or _G.STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"

    local search = CreateFrame("EditBox", nil, picker)
    search:SetHeight(EMOTE_SEARCH_H)
    search:SetPoint("TOPLEFT", picker, "TOPLEFT", EMOTE_PAD, -EMOTE_PAD)
    search:SetPoint("TOPRIGHT", picker, "TOPRIGHT", -EMOTE_PAD, -EMOTE_PAD)
    search:SetAutoFocus(false)
    search:SetTextInsets(7, 7, 0, 0)
    ApplyFont(search, fontPath, 11, fontFlags, "GameFontHighlightSmall")
    search:SetTextColor(1, 1, 1)
    local searchBg = search:CreateTexture(nil, "BACKGROUND")
    searchBg:SetAllPoints(search)
    SetSolid(searchBg, 1, 1, 1, 0.07)
    picker.search = search

    local hint = search:CreateFontString(nil, "OVERLAY")
    ApplyFont(hint, fontPath, 11, fontFlags, "GameFontDisableSmall")
    hint:SetPoint("LEFT", search, "LEFT", 7, 0)
    hint:SetText(T("поиск эмоции", "search emotes"))
    hint:SetTextColor(0.55, 0.55, 0.6)

    search:SetScript("OnTextChanged", function(self)
        local text = self:GetText() or ""
        if text == "" then hint:Show() else hint:Hide() end
        FilterPicker(text)
    end)
    search:SetScript("OnEscapePressed", function(self)
        if (self:GetText() or "") ~= "" then
            self:SetText("")
            self:ClearFocus()
        else
            HidePicker()
        end
    end)
    search:SetScript("OnEnterPressed", function()
        PerformEmote(pickerMatches[1])
    end)

    local gridTop = EMOTE_PAD + EMOTE_SEARCH_H + 6
    for index = 1, EMOTE_COLS * EMOTE_ROWS do
        local col = (index - 1) % EMOTE_COLS
        local row = floor((index - 1) / EMOTE_COLS)
        local cell = CreateFrame("Button", nil, picker)
        cell:SetFrameLevel(picker:GetFrameLevel() + 2)
        cell:SetWidth(EMOTE_CELL_W)
        cell:SetHeight(EMOTE_CELL_H)
        cell:SetPoint("TOPLEFT", picker, "TOPLEFT",
                      EMOTE_PAD + col * EMOTE_CELL_W, -(gridTop + row * EMOTE_CELL_H))

        local highlight = cell:CreateTexture(nil, "HIGHLIGHT")
        highlight:SetPoint("TOPLEFT", 2, 0)
        highlight:SetPoint("BOTTOMRIGHT", -2, 0)
        SetSolid(highlight, 1, 1, 1, 0.12)

        local text = cell:CreateFontString(nil, "OVERLAY")
        ApplyFont(text, fontPath, 11, fontFlags, "GameFontHighlightSmall")
        text:SetPoint("LEFT", cell, "LEFT", 8, 0)
        text:SetWidth(EMOTE_CELL_W - 14)
        text:SetJustifyH("LEFT")
        -- A long localised name is cut off rather than spilling into the
        -- neighbouring column.
        if text.SetWordWrap then pcall(text.SetWordWrap, text, false) end
        text:SetTextColor(0.88, 0.88, 0.92)
        cell.text = text

        cell:SetScript("OnEnter", function(self)
            self.text:SetTextColor(1, 0.85, 0.35)
            -- Name, the command it runs, and the token behind it: enough to
            -- report an emote that misbehaves without guessing which it was.
            local entry = self.entry
            if entry and _G.GameTooltip then
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText(entry.label, 1, 0.82, 0)
                if entry.command then
                    GameTooltip:AddLine("/" .. entry.command, 0.7, 0.7, 0.75, true)
                end
                GameTooltip:AddLine(entry.token, 0.45, 0.45, 0.5, true)
                GameTooltip:Show()
            end
        end)
        cell:SetScript("OnLeave", function(self)
            self.text:SetTextColor(0.88, 0.88, 0.92)
            if _G.GameTooltip then GameTooltip:Hide() end
        end)
        cell:SetScript("OnClick", function(self) PerformEmote(self.entry) end)
        pickerCells[index] = cell
    end

    picker.empty = picker:CreateFontString(nil, "OVERLAY")
    ApplyFont(picker.empty, fontPath, 11, fontFlags, "GameFontDisableSmall")
    picker.empty:SetPoint("TOPLEFT", picker, "TOPLEFT", EMOTE_PAD + 8, -(gridTop + 4))
    picker.empty:SetText(T("ничего не найдено", "nothing found"))
    picker.empty:SetTextColor(0.6, 0.6, 0.65)
    picker.empty:Hide()

    picker.more = picker:CreateFontString(nil, "OVERLAY")
    ApplyFont(picker.more, fontPath, 10, fontFlags, "GameFontDisableSmall")
    picker.more:SetPoint("BOTTOMRIGHT", picker, "BOTTOMRIGHT",
                         -EMOTE_PAD - 2, EMOTE_PAD - 1)
    picker.more:SetText(T("колесо — прокрутка", "scroll for more"))
    picker.more:SetTextColor(0.5, 0.5, 0.55)
    picker.more:Hide()

    picker:SetScript("OnMouseWheel", function(self, delta)
        pickerOffset = pickerOffset - (delta or 0)
        RefreshPicker()
    end)
    picker:SetScript("OnShow", function()
        pickerBlocker:Show()
        search:SetText("")
        hint:Show()
        FilterPicker("")
    end)
    picker:SetScript("OnHide", function()
        pickerBlocker:Hide()
        search:ClearFocus()
    end)

    if type(_G.UISpecialFrames) == "table" then
        tinsert(UISpecialFrames, "ChatOrbsEmotePicker")
    end
    return picker
end

local function TogglePicker(anchorButton)
    local frame = CreatePicker()
    if frame:IsShown() then
        frame:Hide()
        return
    end
    frame:ClearAllPoints()
    local bottom = anchorButton:GetBottom() or 0
    local screen = UIParent:GetHeight() or 768
    if bottom > screen * 0.5 then
        frame:SetPoint("TOP", anchorButton, "BOTTOM", 0, -8)
    else
        frame:SetPoint("BOTTOM", anchorButton, "TOP", 0, 8)
    end
    pickerBlocker:SetFrameLevel(max(1, frame:GetFrameLevel() - 1))
    frame:Show()
end

-- ---------------------------------------------------------------------------
-- The dock
-- ---------------------------------------------------------------------------
local dock = CreateFrame("Frame", "ChatOrbsFrame", UIParent)
dock:SetFrameStrata("MEDIUM")
dock:SetWidth(ORB_STEP * 9)
dock:SetHeight(DOCK_H)
dock:SetMovable(true)
dock:SetClampedToScreen(true)
dock:RegisterForDrag("LeftButton")
dock:Hide()
ChatOrbs.frame = dock

local dockPanel = CreatePanel(dock)
dockPanel:SetAllPoints(dock)
-- Backdrop below, orbs above (CreateButton raises them). Without this the
-- draw order is whatever the creation order gives, which is not something to
-- rely on.
dockPanel:SetFrameLevel(max(1, dock:GetFrameLevel()))

local marker = dock:CreateTexture(nil, "OVERLAY")
marker:SetWidth(MARKER_W)
marker:SetHeight(MARKER_H)
marker:Hide()

local captionFont, captionFlags
do
    local source = _G.GameFontNormal
    if source and source.GetFont then
        local path, _, flags = source:GetFont()
        captionFont, captionFlags = path, flags
    end
    captionFont = captionFont or _G.STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
end

--- The interface is laid out on a grid 768 units tall, so one unit covers
--- `scale * screenHeight / 768` physical pixels. Unless that number is whole,
--- every edge of every texture lands between two pixels and the whole bar goes
--- soft and ragged. Snapping the dock's own scale to a whole (or half) pixel
--- per unit is what keeps it crisp - the same trick pixel-perfect UI addons
--- apply to UIParent, applied to one frame so the rest of the UI is untouched.
local function SnapScale(desired)
    local probe = _G.GetPhysicalScreenSize
    if type(probe) ~= "function" then return desired end
    local ok, _, screenHeight = pcall(probe)
    if not ok or type(screenHeight) ~= "number" or screenHeight <= 0 then
        return desired
    end
    local parent = UIParent:GetEffectiveScale()
    if type(parent) ~= "number" or parent <= 0 then return desired end

    local unit = 768 / screenHeight         -- effective scale of one pixel
    local steps = floor(desired * parent / unit * 2 + 0.5) / 2
    if steps < 0.5 then steps = 0.5 end
    local snapped = steps * unit / parent
    -- A snap that changes the size wildly would be worse than soft edges.
    if snapped < desired * 0.55 or snapped > desired * 1.8 then return desired end
    return snapped
end

--- Re-anchors the dock to UIParent, rounded so its corner sits on a whole
--- physical pixel. GetLeft and SetPoint offsets share the frame's own
--- coordinate space, so no scale conversion is needed beyond the rounding.
local function NormalizeAnchor()
    local left, bottom = dock:GetLeft(), dock:GetBottom()
    if not left or not bottom then return end
    local effective = dock:GetEffectiveScale()
    if type(effective) == "number" and effective > 0 then
        left = floor(left * effective + 0.5) / effective
        bottom = floor(bottom * effective + 0.5) / effective
    end
    dock:ClearAllPoints()
    dock:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", left, bottom)
end

local function StartMove()
    if ChatOrbsDB and ChatOrbsDB.locked then return end
    dock:StartMoving()
    dock.moving = true
end

local function StopMove()
    if not dock.moving then return end
    dock:StopMovingOrSizing()
    dock.moving = false
    NormalizeAnchor()
    ChatOrbs:SavePosition()
end

local function OnButtonEnter(self)
    local entry = self.entry
    if not entry then return end
    SetHover(self, true)
    if _G.GameTooltip then
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(entry.title, 1, 0.82, 0)
        if entry.isEmote then
            GameTooltip:AddLine(T("Щелчок — список эмоций.",
                                  "Click for the emote list."), 1, 1, 1, true)
            GameTooltip:AddLine(T("Правый щелчок — своя эмоция текстом.",
                                  "Right-click to type a custom emote."), 1, 1, 1, true)
        elseif entry.needsTarget then
            GameTooltip:AddLine(T("Щелчок — написать личное сообщение.",
                                  "Click to start a whisper."), 1, 1, 1, true)
        else
            GameTooltip:AddLine(T("Щелчок — писать в этот канал.",
                                  "Click to type in this channel."), 1, 1, 1, true)
        end
        if not (ChatOrbsDB and ChatOrbsDB.locked) then
            GameTooltip:AddLine(T("Перетаскивание — передвинуть панель.",
                                  "Drag to move the dock."), 0.6, 0.6, 0.6, true)
        end
        GameTooltip:Show()
    end
end

local function OnButtonLeave(self)
    SetHover(self, false)
    if _G.GameTooltip then GameTooltip:Hide() end
end

local function OnButtonMouseDown(self)
    self.pressed = true
    ApplyVisual(self)
end

local function OnButtonMouseUp(self)
    self.pressed = false
    ApplyVisual(self)
end

local function OnButtonDragStart(self)
    self.pressed = false
    ApplyVisual(self)
    StartMove()
end

local function OnButtonClick(self, mouseButton)
    local entry = self.entry
    if not entry then return end
    if entry.isEmote and mouseButton ~= "RightButton" then
        TogglePicker(self)
        return
    end
    HidePicker()
    OpenChatFor(entry)
end

--- Applies the look and the channel colour together.
---
--- The colour has to go in here rather than being set afterwards: on clients
--- where SetColorTexture doubles as the vertex colour, a SetVertexColor made
--- before it is thrown away, which is why every orb in texture-free mode came
--- out white instead of taking its channel colour.
local function StyleButton(button, flat, r, g, b)
    r, g, b = r or 1, g or 1, b or 1
    if flat then
        button.orb:SetVertexColor(1, 1, 1)
        SetSolid(button.orb, r, g, b, 1)
        button.sheen:Hide()
        button.glow:Hide()
    else
        button.orb:SetTexture(TEX_ORB)
        button.orb:SetVertexColor(r, g, b)
        button.sheen:SetTexture(TEX_SHEEN)
        button.glow:SetTexture(TEX_GLOW)
        button.glow:SetVertexColor(r, g, b)
        button.sheen:Show()
        button.glow:Show()
    end
end

--- Two-character captions (Гр, Ги, Оф, channel 10) are drawn a point smaller
--- so they still fit inside the orb.
local function ApplyCaption(button, text)
    button.caption:SetText(text)
    local size = (TextLength(text) > 1) and CAPTION_SIZE_WIDE or CAPTION_SIZE
    if button.captionSize ~= size then
        ApplyFont(button.caption, captionFont, size, captionFlags, "GameFontNormal")
        button.captionSize = size
    end
end

local function CreateButton(index)
    local button = CreateFrame("Button", "ChatOrbsButton" .. index, dock)
    button:SetFrameLevel(dock:GetFrameLevel() + 2)
    button:SetWidth(HIT_SIZE)
    button:SetHeight(HIT_SIZE)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    button.glow = button:CreateTexture(nil, "BACKGROUND")
    button.glow:SetWidth(GLOW_SIZE)
    button.glow:SetHeight(GLOW_SIZE)
    button.glow:SetPoint("CENTER")
    button.glow:SetBlendMode("ADD")
    button.glow:SetAlpha(0)

    button.orb = button:CreateTexture(nil, "ARTWORK")
    button.sheen = button:CreateTexture(nil, "OVERLAY")
    button.sheen:SetAlpha(SHEEN_REST)

    button.caption = button:CreateFontString(nil, "OVERLAY")
    ApplyFont(button.caption, captionFont, CAPTION_SIZE, captionFlags,
              "GameFontNormal")
    button.captionSize = CAPTION_SIZE
    -- The glyph is a darkened version of the channel colour; a light edge
    -- keeps it legible against the shaded middle of the sphere.
    if button.caption.SetShadowColor then
        button.caption:SetShadowColor(1, 1, 1, 0.35)
        button.caption:SetShadowOffset(1, -1)
    end

    button.hoverAmount = 0
    -- Rebuild styles and colours the button straight away, so no placeholder
    -- styling is needed here.
    ApplyVisual(button)

    button:RegisterForDrag("LeftButton")
    button:SetScript("OnDragStart", OnButtonDragStart)
    button:SetScript("OnDragStop", StopMove)
    button:SetScript("OnEnter", OnButtonEnter)
    button:SetScript("OnLeave", OnButtonLeave)
    button:SetScript("OnMouseDown", OnButtonMouseDown)
    button:SetScript("OnMouseUp", OnButtonMouseUp)
    button:SetScript("OnHide", OnButtonMouseUp)
    button:SetScript("OnClick", OnButtonClick)
    return button
end

function ChatOrbs:Rebuild()
    local entries = BuildEntries()
    local flat = ChatOrbsDB and ChatOrbsDB.flat

    for index, entry in ipairs(entries) do
        local button = self.buttons[index]
        if not button then
            button = CreateButton(index)
            self.buttons[index] = button
        end
        button.entry = entry
        button:ClearAllPoints()
        button:SetPoint("CENTER", dock, "BOTTOMLEFT",
                        DOCK_INNER + ORB_SIZE / 2 + (index - 1) * ORB_STEP, DOCK_H / 2)
        local r, g, b = ColorFor(entry.colorKey)
        StyleButton(button, flat, r, g, b)
        ApplyCaption(button, entry.caption)
        button.caption:SetTextColor(r * CAPTION_DARKEN, g * CAPTION_DARKEN,
                                    b * CAPTION_DARKEN)
        button.hoverAmount = 0
        button.pressed = false
        tweening[button] = nil
        ApplyVisual(button)
        button:Show()
    end

    for index = #entries + 1, #self.buttons do
        self.buttons[index].entry = nil
        self.buttons[index]:Hide()
    end

    local count = max(#entries, 1)
    dock:SetWidth((count - 1) * ORB_STEP + ORB_SIZE + DOCK_INNER * 2)
    dock:SetHeight(DOCK_H)
    dockPanel:Layout()
    dockPanel:Restyle(flat)
    if marker.SetTexture and not flat then
        marker:SetTexture(TEX_MARKER)
    elseif marker.SetColorTexture then
        marker:SetColorTexture(1, 1, 1, 1)
    end
    -- The buttons were just re-pointed at new entries, so the remembered key
    -- no longer says which orb the marker belongs under, and its colour may
    -- have just been reset. Force a fresh lookup.
    self.markerKey = nil
    self:UpdateMarker()
end

--- Highlights the orb the chat edit box is currently pointed at.
function ChatOrbs:UpdateMarker()
    local editBox = GetEditBox()
    local key
    if editBox and editBox:IsShown() then
        local chatType = editBox:GetAttribute("chatType")
        if chatType == "CHANNEL" then
            key = "CHANNEL" .. tostring(editBox:GetAttribute("channelTarget"))
        elseif type(chatType) == "string" then
            key = chatType
        end
    end
    if key == self.markerKey then return end
    self.markerKey = key

    for _, button in ipairs(self.buttons) do
        if button.entry and button:IsShown() and button.entry.key == key then
            local r, g, b = ColorFor(button.entry.colorKey)
            marker:ClearAllPoints()
            marker:SetPoint("CENTER", button, "CENTER", 0, -(ORB_SIZE / 2 + 3))
            marker:SetVertexColor(r, g, b)
            marker:Show()
            return
        end
    end
    marker:Hide()
end

function ChatOrbs:SavePosition()
    local point, _, relPoint, x, y = dock:GetPoint()
    if not point or not x or not y then return end
    ChatOrbsDB.point, ChatOrbsDB.relPoint = point, relPoint
    ChatOrbsDB.x, ChatOrbsDB.y = x, y
end

function ChatOrbs:RestorePosition()
    dock:ClearAllPoints()
    if ChatOrbsDB.x and ChatOrbsDB.y then
        dock:SetPoint(ChatOrbsDB.point or "BOTTOMLEFT", UIParent,
                      ChatOrbsDB.relPoint or "BOTTOMLEFT", ChatOrbsDB.x, ChatOrbsDB.y)
        return
    end
    if _G.ChatFrame1 then
        dock:SetPoint("BOTTOMLEFT", _G.ChatFrame1, "TOPLEFT", 0, 34)
    else
        dock:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 35, 340)
    end
    NormalizeAnchor()
    self:SavePosition()
end

function ChatOrbs:ApplyLock()
    dock:EnableMouse(not ChatOrbsDB.locked)
end

function ChatOrbs:ApplyScale(newScale)
    local point, _, relPoint, x, y = dock:GetPoint()
    local old = dock:GetScale()
    local applied = SnapScale(newScale)
    dock:SetScale(applied)
    -- SetPoint offsets live in the frame's own scale, so they need converting
    -- for the dock to stay where it looks like it is.
    if point and x and y and old and old > 0 then
        dock:ClearAllPoints()
        dock:SetPoint(point, UIParent, relPoint, x * old / applied, y * old / applied)
    end
    NormalizeAnchor()
    ChatOrbsDB.scale = newScale
    self:SavePosition()
    return applied
end

function ChatOrbs:ApplyVisibility()
    if ChatOrbsDB.hidden then
        HidePicker()
        dock:Hide()
    else
        dock:Show()
    end
end

-- ---------------------------------------------------------------------------
-- Deferred rebuild
-- ---------------------------------------------------------------------------
local rebuildPending, timerFrame = false, nil

local function DoRebuild()
    rebuildPending = false
    ChatOrbs:Rebuild()
end

local function RequestRebuild()
    if rebuildPending then return end
    rebuildPending = true
    if _G.C_Timer and C_Timer.After then
        C_Timer.After(0.2, DoRebuild)
        return
    end
    if not timerFrame then timerFrame = CreateFrame("Frame") end
    timerFrame.elapsed = 0
    timerFrame:SetScript("OnUpdate", function(self, elapsed)
        self.elapsed = self.elapsed + (elapsed or 0)
        if self.elapsed >= 0.2 then
            self:SetScript("OnUpdate", nil)
            DoRebuild()
        end
    end)
end

-- ---------------------------------------------------------------------------
-- Slash commands
-- ---------------------------------------------------------------------------
local function OnOff(value)
    if value then return T("вкл", "on") end
    return T("выкл", "off")
end

local function PrintHelp()
    Print(T("доступные команды:", "available commands:"))
    local sticky = ChatOrbsDB and ChatOrbsDB.sticky
    local full = ChatOrbsDB and ChatOrbsDB.allEmotes
    local lines = {
        { "/chatorbs",         T("список команд.", "show this list.") },
        { "/chatorbs emotes",  T("список эмоций: короткий (нужное) или полный "
                                 .. "(всё, что знает клиент). Сейчас: "
                                 .. (full and "полный" or "короткий") .. ".",
                                 "emote list: short (the useful ones) or full "
                                 .. "(everything the client knows). Now: "
                                 .. (full and "full" or "short") .. ".") },
        { "/chatorbs sticky",  T("залипание канала: после Enter строка ввода "
                                 .. "снова открывается в том же канале (сейчас: "
                                 .. OnOff(sticky) .. ").",
                                 "sticky channel: after Enter the edit box "
                                 .. "reopens in the same channel (now: "
                                 .. OnOff(sticky) .. ").") },
        { "/chatorbs lock",    T("запретить перемещение.", "lock the dock in place.") },
        { "/chatorbs unlock",  T("разрешить перемещение.", "allow dragging the dock.") },
        { "/chatorbs reset",   T("вернуть положение и масштаб по умолчанию.",
                                 "restore the default position and scale.") },
        { "/chatorbs scale 1", T("масштаб панели (0.5 - 3).", "dock scale (0.5 - 3).") },
        { "/chatorbs hide",    T("скрыть панель.", "hide the dock.") },
        { "/chatorbs show",    T("показать панель.", "show the dock.") },
        { "/chatorbs flat",    T("режим без текстур — на случай, если кнопки не видны.",
                                 "texture-free mode, in case the orbs do not render.") },
    }
    for _, line in ipairs(lines) do
        Print("|cff80ff80" .. line[1] .. "|r — " .. line[2])
    end
end

local function HandleSlash(input)
    input = strtrim(strlower(input or ""))
    local command, argument = input:match("^(%S*)%s*(.-)$")

    if command == "" then
        PrintHelp()

    elseif command == "lock" then
        ChatOrbsDB.locked = true
        ChatOrbs:ApplyLock()
        Print(T("панель закреплена.", "dock locked."))

    elseif command == "unlock" then
        ChatOrbsDB.locked = false
        ChatOrbs:ApplyLock()
        Print(T("панель откреплена, её можно перетаскивать.",
                "dock unlocked, drag it anywhere."))

    elseif command == "reset" then
        ChatOrbsDB.point, ChatOrbsDB.relPoint = nil, nil
        ChatOrbsDB.x, ChatOrbsDB.y = nil, nil
        ChatOrbsDB.scale = 1
        dock:SetScale(SnapScale(1))
        ChatOrbs:RestorePosition()
        Print(T("положение и масштаб сброшены.", "position and scale reset."))

    elseif command == "scale" then
        local value = tonumber(argument)
        if not value then
            Print(T("текущий масштаб: ", "current scale: ")
                  .. string.format("%.3f", dock:GetScale() or 1))
        elseif value < MIN_SCALE or value > MAX_SCALE then
            Print(T("масштаб должен быть от 0.5 до 3.",
                    "scale must be between 0.5 and 3."))
        else
            local applied = ChatOrbs:ApplyScale(value)
            local message = T("масштаб: ", "scale: ") .. value
            if applied and math.abs(applied - value) > 0.01 then
                message = message
                    .. T(" (подогнан до ", " (snapped to ")
                    .. string.format("%.3f", applied)
                    .. T(", чтобы края попадали на целые пиксели)",
                         " so edges land on whole pixels)")
            end
            Print(message)
        end

    elseif command == "hide" then
        ChatOrbsDB.hidden = true
        ChatOrbs:ApplyVisibility()
        Print(T("панель скрыта. Вернуть: /chatorbs show",
                "dock hidden. Use /chatorbs show to bring it back."))

    elseif command == "show" then
        ChatOrbsDB.hidden = false
        ChatOrbs:ApplyVisibility()
        Print(T("панель показана.", "dock shown."))

    elseif command == "emotes" then
        if argument == "all" or argument == "все" or argument == "полный" then
            ChatOrbsDB.allEmotes = true
        elseif argument == "short" or argument == "короткий" then
            ChatOrbsDB.allEmotes = false
        else
            ChatOrbsDB.allEmotes = not ChatOrbsDB.allEmotes
        end
        if picker and picker:IsShown() then
            FilterPicker(picker.search:GetText() or "")
        end
        if ChatOrbsDB.allEmotes then
            Print(T("список эмоций: полный — всё, что знает клиент.",
                    "emote list: full - everything the client knows."))
        else
            Print(T("список эмоций: короткий. Остальные находятся поиском.",
                    "emote list: short. The rest are found by searching."))
        end

    elseif command == "sticky" then
        if argument == "on" or argument == "вкл" then
            ChatOrbsDB.sticky = true
        elseif argument == "off" or argument == "выкл" then
            ChatOrbsDB.sticky = false
        else
            ChatOrbsDB.sticky = not ChatOrbsDB.sticky
        end
        ApplyStickyFlags()
        if ChatOrbsDB.sticky then
            Print(T("залипание канала включено: написали в группу, нажали "
                    .. "Enter - строка ввода снова откроется в группу. "
                    .. "Крик и эмоции остаются разовыми.",
                    "sticky channel on: write to the party, press Enter and "
                    .. "the edit box reopens in the party. Yell and emotes "
                    .. "stay one-shot."))
        else
            Print(T("залипание канала выключено: строка ввода возвращается "
                    .. "к тому, что настроено в самой игре.",
                    "sticky channel off: the edit box falls back to the "
                    .. "game's own setting."))
        end

    elseif command == "flat" then
        ChatOrbsDB.flat = not ChatOrbsDB.flat
        ChatOrbs:Rebuild()
        if picker then picker.panel:Restyle(ChatOrbsDB.flat) end
        if ChatOrbsDB.flat then
            Print(T("режим без текстур включён.", "texture-free mode on."))
        else
            Print(T("режим без текстур выключен.", "texture-free mode off."))
        end

    else
        Print(T("неизвестная команда: ", "unknown command: ") .. command)
        PrintHelp()
    end
end

-- ---------------------------------------------------------------------------
-- Events
-- ---------------------------------------------------------------------------
local DEFAULTS = {
    scale = 1, locked = false, hidden = false, flat = false,
    -- On by default: this is the behaviour the dock is for, and /chatorbs
    -- sticky turns it off again.
    sticky = true,
    -- The short emote list by default; /chatorbs emotes shows the lot.
    allEmotes = false,
}

local events = CreateFrame("Frame")

local function Register(event)
    pcall(events.RegisterEvent, events, event)
end

local function HookEditBox()
    local editBox = GetEditBox()
    if not editBox or editBox.chatOrbsHooked or not editBox.HookScript then return end
    editBox.chatOrbsHooked = true
    local function refresh() ChatOrbs:UpdateMarker() end
    pcall(editBox.HookScript, editBox, "OnShow", refresh)
    pcall(editBox.HookScript, editBox, "OnHide", refresh)
    pcall(editBox.HookScript, editBox, "OnTextChanged", refresh)
end

events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")

events:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 ~= ADDON_NAME then return end
        if type(_G.ChatOrbsDB) ~= "table" then _G.ChatOrbsDB = {} end
        for key, value in pairs(DEFAULTS) do
            if ChatOrbsDB[key] == nil then ChatOrbsDB[key] = value end
        end
        local scale = tonumber(ChatOrbsDB.scale)
        if not scale or scale < MIN_SCALE or scale > MAX_SCALE then
            ChatOrbsDB.scale = 1
        end
        self:UnregisterEvent("ADDON_LOADED")

    elseif event == "PLAYER_LOGIN" then
        ApplyStickyFlags()
        dock:SetScale(SnapScale(ChatOrbsDB.scale or 1))
        ChatOrbs:RestorePosition()
        ChatOrbs:ApplyLock()
        ChatOrbs:Rebuild()
        ChatOrbs:ApplyVisibility()
        HookEditBox()

        -- Events that change which chat targets exist. Registration is wrapped
        -- because an unknown event name is a hard error on current clients and
        -- these names differ between game versions.
        Register("PLAYER_ENTERING_WORLD")
        Register("GROUP_ROSTER_UPDATE")
        Register("PARTY_MEMBERS_CHANGED")
        Register("RAID_ROSTER_UPDATE")
        Register("PLAYER_GUILD_UPDATE")
        Register("CHANNEL_UI_UPDATE")
        Register("CHAT_MSG_CHANNEL_NOTICE")
        Register("UPDATE_CHAT_COLOR")
        Register("BN_CONNECTED")
        Register("BN_DISCONNECTED")
        self:UnregisterEvent("PLAYER_LOGIN")

    else
        HookEditBox()
        RequestRebuild()
    end
end)

dock:SetScript("OnDragStart", StartMove)
dock:SetScript("OnDragStop", StopMove)

SLASH_CHATORBS1 = "/chatorbs"
SlashCmdList["CHATORBS"] = HandleSlash

_G.ChatOrbs = ChatOrbs
